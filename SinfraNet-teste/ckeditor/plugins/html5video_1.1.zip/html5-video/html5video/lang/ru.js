CKEDITOR.plugins.setLang( 'html5video', 'ru', {
    button: 'Вставить HTML5 видео',
    title: 'HTML5 видео',
    infoLabel: 'Видео',
    allowed: 'Допустимые расширения файлов: MP4, WebM, Ogv',
    urlMissing: 'Не выбран источник видео',
    videoProperties: 'Свойства видео',
    upload: 'Загрузить',
    btnUpload: 'Загрузить на сервер',
    advanced: 'Дополнительно',
    autoplay: 'Автовоспроизведение',
    yes: 'Да',
    no: 'Нет',
    responsive: 'Адаптивная ширина'
} );
